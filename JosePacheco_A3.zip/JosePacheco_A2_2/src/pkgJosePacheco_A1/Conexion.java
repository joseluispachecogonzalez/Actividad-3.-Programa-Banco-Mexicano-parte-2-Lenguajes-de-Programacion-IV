/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkgJosePacheco_A1;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;




/**
 *
 * @author josel
 */
public class Conexion {
    public Connection getConnection(){
        Connection con = null;
        String base = "bdactividad2";
        String url = "jdbc:mysql://localhost:3306/" + base;
        String user = "root";
        String password = "";
        //intetará hacer la conexión
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con =(Connection) DriverManager.getConnection(url, user, password);
            //si no conecta lanzará una excepción que rerorne a la conexión
        } catch(Exception e){
          System.err.println(e);
          
          
        }
        return con;
    }    
    
}
